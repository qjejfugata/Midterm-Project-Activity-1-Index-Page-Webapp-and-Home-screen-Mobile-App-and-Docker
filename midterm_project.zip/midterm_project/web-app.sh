#!/bin/bash
mkdir tempdir
mkdir tempdir/templates
mkdir tempdir/static
cp web-app.py tempdir/.
cp -r templates/* tempdir/templates/.
cp -r static/* tempdir/static/.
echo "From python" > tempdir/Dockerfile
echo "RUN pip3 install flask" >> tempdir/Dockerfile
echo "COPY ./static /home/myapp/static/" >> tempdir/Dockerfile
echo "COPY ./templates /home/myapp/templates/" >>tempdir/Dockerfile
echo "COPY web-app.py /home/myapp/" >> tempdir/Dockerfile
echo "EXPOSE 5050" >> tempdir/Dockerfile
echo "CMD python3 /home/myapp/web-app.py" >> tempdir/Dockerfile

cd tempdir

docker build -t designapp .
docker run -t -d -p 5050:5050--name designapprunning designapp
docker ps -a
