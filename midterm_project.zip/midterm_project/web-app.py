from flask import Flask
from flask import request
from flask import render_template
import os
sample = Flask(__name__)

picFolder = os.path.join('static','pics')

sample.config['UPLOAD_FOLDER'] = picFolder
@sample.route("/")

def main():
    pic1 = os.path.join(sample.config['UPLOAD_FOLDER'], 'focus.png')
    pic2 = os.path.join(sample.config['UPLOAD_FOLDER'], 'safety.png')
    pic3 = os.path.join(sample.config['UPLOAD_FOLDER'], 'enviro.png')
    return render_template("index.html", img1 = pic1, img2 = pic2, img3 = pic3)

if __name__ == "__main__":
    sample.run(host="0.0.0.0", port=5050)

